//
//  TiSuperwallTambitsoftwareCom.h
//  ti.superwall
//
//  Created by Your Name
//  Copyright (c) 2024 Your Company. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TiSuperwallTambitsoftwareCom.
FOUNDATION_EXPORT double TiSuperwallTambitsoftwareComVersionNumber;

//! Project version string for TiSuperwallTambitsoftwareCom.
FOUNDATION_EXPORT const unsigned char TiSuperwallTambitsoftwareComVersionString[];

#import "TiSuperwallTambitsoftwareComModuleAssets.h"
